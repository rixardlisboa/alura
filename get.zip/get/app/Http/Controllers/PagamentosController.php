<?php


namespace App\Http\Controllers;


class PagamentosController extends Controller
{
    public function index()
    {
        $pagamentos = [
            'Nome',
            'endereço',
            'telefone'
        ];
        return view('pagamentos.index', compact('pagamentos'));
    }
}