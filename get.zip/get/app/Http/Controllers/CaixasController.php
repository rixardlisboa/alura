<?php


namespace App\Http\Controllers;
use App\Caixa;
use Illuminate\Http\Request;

class CaixasController extends Controller
{
    public function index(Request $request) {

        $caixas = Caixa::paginate(10);
        $mensagem = $request->session()->get('mensagem');

        return view('caixas.index', compact('caixas', 'mensagem'));
    }

    public function create()
    {
        return view('caixas.create');
    }
    public function store(Request $request)
    {
        $nome = $request->nome;
        $saldo = $request->saldo;


        $caixa = new Caixa();

        $caixa->nome = $nome;
        $caixa->saldo = $saldo;


        $caixa->save();

        $request->session()
            ->flash(
                'mensagem',
                "Caixa {$caixa->id} criado com Sucesso {$caixa->nome}
                ");

        return redirect()->route('listar_caixas');
    }

    public function destroy (Request $request)

    {

        Caixa::destroy($request->id);
        $request->session()
            ->flash(
                'mensagem',
                "Caixa removido com sucesso"
            );

        return redirect()->route('listar_caixas');

    }
}