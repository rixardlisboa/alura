<?php

namespace App\Http\Controllers;

use App\Tipo;
use Illuminate\Http\Request;

class TiposController extends Controller
{
    public function index(Request $request) {
        $tipos = Tipo::paginate(10);
        $mensagem = $request->session()->get('mensagem');

        return view('tipos.index', compact('tipos', 'mensagem'));
    }

    public function create()
    {
        return view('tipos.create');
    }
    public function store(Request $request)
    {
        $nome = $request->nome;

        $tipo = new Tipo();

        $tipo->nome = $nome;

        $tipo->save();

        $request->session()
            ->flash(
                'mensagem',
                "Tipo {$tipo->id} criado com Sucesso {$tipo->nome}
                ");

        return redirect()->route('listar_tipos');
    }

    public function destroy (Request $request)

    {

        Tipo::destroy($request->id);
        $request->session()
            ->flash(
                'mensagem',
                "Tipo removido com sucesso"
            );

        return redirect()->route('listar_tipos');

    }
}