<?php

namespace App\Http\Controllers;

use App\Cargo;
use Illuminate\Http\Request;

class CargosController extends Controller
{
    public function index(Request $request) {
        $cargos = Cargo::paginate(10);
        $mensagem = $request->session()->get('mensagem');

        return view('cargos.index', compact('cargos', 'mensagem'));
    }

    public function create()
    {
        return view('cargos.create');
    }
    public function store(Request $request)
    {
        $nome = $request->nome;

        $cargo = new Cargo();

        $cargo->nome = $nome;

        $cargo->save();

        $request->session()
            ->flash(
                'mensagem',
                "Cargo {$cargo->id} criada com Sucesso {$cargo->nome}
                ");

        return redirect()->route('listar_cargos');
    }

    public function destroy (Request $request)

    {

        Cargo::destroy($request->id);
        $request->session()
            ->flash(
                'mensagem',
                "Cargo removido com sucesso"
            );

        return redirect()->route('listar_cargos');

    }
}