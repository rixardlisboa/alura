<?php


namespace App\Http\Controllers;

use App\Classe;
use App\Produto;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class ProdutosController extends Controller
{
    public function index(Request $request) {
        $produtos = Produto::paginate(10);
        $mensagem = $request->session()->get('mensagem');

        return view('produtos.index', compact('produtos', 'mensagem'));
    }
    private function getClasses()
    {

        $classesList = Classe::all();

        return $classesList;

    }
    public function create()
    {
        $classes = $this->getClasses();
        return view('produtos.create', compact('classes'));
    }

    public function store(Request $request)
    {
        $nome = $request->nome;

        $preco = $request->preco;
        $quantidade = $request->quantidade;
        $unidade_de_venda = $request->unidade_de_venda;

        $ean = $request->ean;
        $descricao = $request->descricao;
        $classe = $request->classe_id;

        $produto = new Produto();

        $produto->nome = $nome;
        $produto->preco = $preco;
        $produto->quantidade = $quantidade;

        $produto->unidade_de_venda = $unidade_de_venda;

        $produto->ean = $ean;
        $produto->descricao = $descricao;
        $produto->classe_id = $classe;

        $produto->save();
        $request->session()
            ->flash(
                'mensagem',
                "Produto {$produto->id} criado com Sucesso {$produto->nome}
                ");

        return redirect()->route('listar_produtos');
    }

    public function destroy (Request $request)

    {

        Produto::destroy($request->id);
        $request->session()
            ->flash(
        'mensagem',
        "Produto removido com sucesso"
        );

    return redirect()->route('listar_produtos');

}

}