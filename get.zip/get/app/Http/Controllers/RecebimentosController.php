<?php


namespace App\Http\Controllers;


class RecebimentosController extends Controller
{
    public function index()
    {
        $recebimentos = [
            'Nome',
            'endereço',
            'telefone'
        ];
        return view('recebimentos.index', compact('recebimentos'));
    }
}