<?php


namespace App\Http\Controllers;


use App\Conta;
use Illuminate\Http\Request;

class ContasController
{
    public function index(Request $request) {
        $contas = Conta::paginate(10);
        $mensagem = $request->session()->get('mensagem');

        return view('contas.index', compact('contas', 'mensagem'));
    }
    public function create()
    {
        return view('contas.create');
    }
    public function store(Request $request)
    {
        $nome = $request->nome;


        $conta = new Conta();

        $conta->nome = $nome;

        $conta->save();

        $request->session()
            ->flash(
                'mensagem',
                "Plano de Contas {$conta->id} criado com Sucesso {$conta->nome}
                ");

        return redirect()->route('listar_contas');
    }

    public function destroy (Request $request)

    {

        Conta::destroy($request->id);
        $request->session()
            ->flash(
                'mensagem',
                "Plano de contas removido com sucesso"
            );

        return redirect()->route('listar_contas');

    }
}