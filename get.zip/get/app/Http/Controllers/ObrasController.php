<?php


namespace App\Http\Controllers;
use App\Obra;
use Illuminate\Http\Request;

class ObrasController extends Controller
{
        public function index(Request $request) {
            $obras = Obra::paginate(10);
        $mensagem = $request->session()->get('mensagem');

        return view('obras.index', compact('obras', 'mensagem'));
    }
    public function create()
    {
        return view('obras.create');
    }
    public function store(Request $request)
    {
        $nome = $request->nome;


        $obra = new Obra();

        $obra->nome = $nome;

        $obra->save();

        $request->session()
            ->flash(
                'mensagem',
                "Obra {$obra->id} criado com Sucesso {$obra->nome}
                ");

        return redirect()->route('listar_obras');
    }

    public function destroy (Request $request)

    {

        Obra::destroy($request->id);
        $request->session()
            ->flash(
                'mensagem',
                "Obra removido com sucesso"
            );

        return redirect()->route('listar_obras');

    }
}