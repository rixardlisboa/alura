<?php


namespace App;


use Illuminate\Database\Eloquent\Model;

class Tipo extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'id',
        'nome',
    ];
    protected $table = 'tipos';

    public function clientes()
    {
        return $this->hasMany(Cliente::class, 'cliente_id');
    }
}
