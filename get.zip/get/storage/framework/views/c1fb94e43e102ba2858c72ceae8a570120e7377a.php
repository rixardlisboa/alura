<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GET EMPREENDIMENTOS</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

    <script>

        function exibeMsg( valor )
        {

            switch (valor)
            {
                case '1':
                    document.getElementById( 'txt' ).innerHTML = 'RG ';
                    document.getElementById( 'txt2' ).innerHTML = 'CPF ';
                    break;

                case '2':
                    document.getElementById( 'txt' ).innerHTML = 'Inscrição Estadual ';
                    document.getElementById( 'txt2' ).innerHTML = 'CNPJ ';
                    break;
                default:
                    document.getElementById( 'txt' ).innerHTML = 'Nenhum valor informado';
                    break;
            }
        }

    </script>

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light mx-auto" style="width: 70%;">
    <img src="https://static.wixstatic.com/media/9688f3_74ef83a2b16e4356814310e9d008e52f~mv2.png/v1/fill/w_184,h_59,al_c,q_80,usm_0.66_1.00_0.01/01.webp" width="70" height="30"  class="d-inline-block align-top mr-5" alt="">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Alterna navegação">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"style="color: #0D5C95;">
                    Cadastro
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="/produtos" style="color: #0D5C95;">Suprimentos</a>
                    <a class="dropdown-item" href="/classes" style="color: #0D5C95;">Classes</a>
                    <a class="dropdown-item" href="/clientes" style="color: #0D5C95;">Clientes e Fornecedores</a>
                    <a class="dropdown-item" href="/funcionarios" style="color: #0D5C95;">Funcionários</a>
                    <a class="dropdown-item" href="/cargos" style="color: #0D5C95;">Cargos</a>
                    <a class="dropdown-item" href="/caixas" style="color: #0D5C95;">Caixas</a>
                    <a class="dropdown-item" href="/bancos" style="color: #0D5C95;">Bancos</a>
                    <a class="dropdown-item" href="/obras" style="color: #0D5C95;">Obras</a>
                    <a class="dropdown-item" href="/contas" style="color: #0D5C95;">Plano de Contas</a>
                </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: #0D5C95;">
                    Financeiro
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink" style="color: #0D5C95;">
                    <a class="dropdown-item" href="/pagamentos" style="color: #0D5C95;">A Pagar</a>
                    <a class="dropdown-item" href="/recebimentos" style="color: #0D5C95;">A Receber</a>
                    <a class="dropdown-item" href="#" style="color: #0D5C95;">Movimentação do Caixa</a>
                    <a class="dropdown-item" href="#" style="color: #0D5C95;">Transferencias</a>
                </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: #0D5C95;">
                    Engenharia
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink" style="color: #0D5C95;">
                    <a class="dropdown-item" href="#" style="color: #0D5C95;">Prospecção</a>
                    <a class="dropdown-item" href="#" style="color: #0D5C95;">Solicitaçao de Compra</a>
                    <a class="dropdown-item" href="#" style="color: #0D5C95;">Pedido de Compra</a>
                    <a class="dropdown-item" href="#" style="color: #0D5C95;">Andamento da Obra</a>
                    <a class="dropdown-item" href="#" style="color: #0D5C95;">Diário de Obra</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#" style="color: #0D5C95;">Chat</a>
            </li>
        </ul>
    </div>
    <?php if(auth()->guard()->check()): ?>
        <a href="/sair" class="text-danger">Sair</a>
    <?php endif; ?>

    <?php if(auth()->guard()->guest()): ?>
        <a STYLE="color: #0D5C95" class="btn btn-bd-download d-none d-lg-inline-block mb-3 mb-md-0 ml-md-3" href="/entrar">Entrar</a>
    <?php endif; ?>
</nav>



    <div class="container-fluid" style="width: 71%;">
        <div class="jumbotron jumbotron-fluid" style="padding-left: 11%; padding-bottom: 30px; padding-top: 20px; margin-left: -11%; margin-bottom: 20px; color: #0D5C95; height: 40px; background-color: white;">
            <h3><?php echo $__env->yieldContent('cabecalho'); ?></h3>
        </div>

        <?php echo $__env->yieldContent('conteudo'); ?>
    </div>
</body>
</html><?php /**PATH C:\Users\Richard Lisboa\Desktop\get\resources\views/layout.blade.php ENDPATH**/ ?>