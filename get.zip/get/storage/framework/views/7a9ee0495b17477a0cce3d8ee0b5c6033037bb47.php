<?php $__env->startSection('cabecalho'); ?>
    Adicionar Banco
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <form method="post">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="form-group">
                    <label for="nome">Nome</label>
                    <input type="text" name="nome"  class="form-control" placeholder="Nome" required>
                </div>
                <div class="form-group">
                    <label for="tipo">Tipo de Conta</label>
                    <select class="form-control" name="tipo">
                        <option></option>
                        <option>Poupança</option>
                        <option>Corrente</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="agencia">Agencia</label>
                    <input type="text" name="agencia"  step="0.01" min="0" class="form-control" placeholder="Agencia" required>
                </div>
                <div class="form-group">
                    <label for="conta">Conta</label>
                    <input type="number" name="conta"  class="form-control" placeholder="Conta" required>
                </div>
                <div class="form-group">
                    <label for="digito">Dígito</label>
                    <input type="number" name="digito"  class="form-control" placeholder="Dígito" required>
                </div>
                <div class="form-group">
                    <label for="nomebanco">Banco</label>
                    <select class="form-control" name="nomebanco">
                        <option></option>
                        <option>25 - BANCO ALFA</option>
                        <option>318 - BANCO BMG</option>
                        <option>237 - BANCO BRADESCO</option>
                        <option>233 - BANCO CIFRA</option>
                        <option>745 - BANCO CITIBANK</option>
                        <option>3 - BANCO AMAZONIA</option>
                        <option>1 - BANCO BRASIL</option>
                        <option>47 - BANCO DO ESTADO DE SE</option>
                        <option>37 - BANCO DO ESTADO DO PA</option>
                        <option>41 - BANCO DO ESTADO DO RS</option>
                        <option>4 - BANCO DO NORDESTE</option>
                        <option>653 - BANCO INDUSVAL</option>
                        <option>74 - BANCO J SAFRA</option>
                        <option>389 - BANCO MERCANTIL</option>
                        <option>66 - BANCO MORGAN STANLEY</option>
                        <option>45 - BANCO OPPORTUNITY</option>
                        <option>453 - BANCO RURAL</option>
                        <option>72 - BANCO RURAL MAIS</option>
                        <option>422 - BANCO SAFRA</option>
                        <option>655 - BANCO VOTORANTIM</option>
                        <option>24 - BANEPE</option>
                        <option>29 - BANERJ</option>
                        <option>21 - BANESTES</option>
                        <option>21 - BANESTES</option>
                        <option>96 - BM&BOVESPA</option>
                        <option>752 - BNP PARIBAS BRASIL</option>
                        <option>69 - BPN BRASIL</option>
                        <option>70 - BRB</option>
                        <option>208 - BTG PACTUAL</option>
                        <option>104 - CAIXA ECONOMICA FEDERAL</option>
                        <option>477 - CITIBANK</option>
                        <option>487 - DEUTSCHE BANK</option>
                        <option>62 - HIPERCARD</option>
                        <option>492 - ING BANK NV</option>
                        <option>341 - ITAÚ UNIBANCO</option>
                        <option>652 - ITAÚ UNIBANCO HOLDING</option>
                        <option>479 - ITAÚBANK SA</option>
                        <option>488 - JPMORGAN CHASE</option>
                        <option>254 - PARANA BANCO</option>
                        <option>747 - RABOBANK</option>
                        <option>33 - SANTANDER</option>
                        <option>748 - SICRED</option>
                        <option>409 - UNIBANCO</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="saldo">Saldo Inicial</label>
                    <input type="number" name="saldo"  step="0.01" min="0" class="form-control" placeholder="Saldo Inicial" required>
                </div>

                <button class="btn btn-primary" style="background-color: #0D5C95; color: white;">Adicionar</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Richard Lisboa\Desktop\get\resources\views/bancos/create.blade.php ENDPATH**/ ?>