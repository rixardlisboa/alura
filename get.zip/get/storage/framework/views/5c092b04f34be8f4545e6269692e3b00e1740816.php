<?php if(!empty($mensagem)): ?>
    <div class="alert alert-success">
        <?php echo e($mensagem); ?>

    </div>
<?php endif; ?>
<?php /* E:\vinicius-dias\1190-laravel-parte1\controle-series\resources\views/mensagem.blade.php */ ?>