<?php $__env->startSection('cabecalho'); ?>
    A Pagar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

    <?php if(!empty($mensagem)): ?>
        <div class="alert alert-success">
            <?php echo e($mensagem); ?>

        </div>
    <?php endif; ?>

        <a href="<?php echo e(route('form_criar_cliente')); ?>" class="btn btn-dark mb-2" style="margin-left: 90%; margin-top: -100px; background-color: #0D5C95; color: white;">Adicionar</a>


    <ul class="list-group" style="margin-top: -25px">
        <table class="table table-hover">
            <thead style="background-color: #808080;">
            <tr>
                <td>Origem</td>
                <td>S</td>
                <td>Nome</td>
                <td>Emissão</td>
                <td>Vencimento</td>
                <td>Valor</td>
                <td>Desconto</td>
                <td>Juros</td>
                <td>Multa</td>
                <td>Total</td>
                <td>Valor Pago</td>
                <td>Data de Pgto</td>
                <td>Caixa</td>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($pagamentos as $pagamento):?>
            <?php endforeach; ?>
            </tbody>
        </table>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Richard Lisboa\Desktop\get\resources\views/pagamentos/index.blade.php ENDPATH**/ ?>