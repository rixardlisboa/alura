<?php $__env->startSection('cabecalho'); ?>
    Adicionar Produto
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <form method="post">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="form-group">
                    <label for="nome">Produto</label>
                    <input type="text" name="nome"  class="form-control" placeholder="Nome do Produto" required>
                </div>
                <div class="form-group">
                    <label for="unidade_de_venda">Unidade</label>
                    <select class="form-control" name="unidade_de_venda">
                        <option></option>
                        <option>UN</option>
                        <option>MT</option>
                        <option>KG</option>
                        <option>RL</option>
                        <option>PC</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="ean">EAN</label>
                    <input type="number" name="ean"  min="0" class="form-control" placeholder="EAN do Produto">
                </div>
                <div class="form-group" style="display: none;">
                    <label for="preco">Preço</label>
                    <input type="number" name="preco"  value="0" min="0" class="form-control" placeholder="Preço">
                </div>
                <div class="form-group" style="display: none;">
                    <label for="quantidade">Quantidade</label>
                    <input type="number" name="quantidade"  value="0" min="0" class="form-control" placeholder="Quantidade">
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição</label>
                    <input type="text" name="descricao"  step="0.01" min="0" class="form-control" placeholder="Descrição do Produto" required>
                </div>
                <div class="form-group">
                    <label for="classe_id">Categorias</label>
                    <select class="form-control" name="classe_id">
                        <option>Selecione a Categoria</option>
                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($classe->id); ?>"><?php echo e($classe->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>
                <button class="btn btn-primary" style="background-color: #0D5C95; color: white;">Adicionar</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Richard Lisboa\Desktop\get\resources\views/produtos/create.blade.php ENDPATH**/ ?>