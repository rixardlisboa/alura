@extends('layout')

@section('cabecalho')
    Funcionários
@endsection

@section('conteudo')

    @if(!empty($mensagem))
        <div class="alert alert-success">
            {{ $mensagem }}
        </div>
    @endif

@endsection