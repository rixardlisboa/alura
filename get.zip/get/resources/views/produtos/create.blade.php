@extends('layout')

@section('cabecalho')
    Adicionar Produto
@endsection

@section('conteudo')
    <form method="post">
        @csrf
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="form-group">
                    <label for="nome">Produto</label>
                    <input type="text" name="nome"  class="form-control" placeholder="Nome do Produto" required>
                </div>
                <div class="form-group">
                    <label for="unidade_de_venda">Unidade</label>
                    <select class="form-control" name="unidade_de_venda">
                        <option></option>
                        <option>UN</option>
                        <option>MT</option>
                        <option>KG</option>
                        <option>RL</option>
                        <option>PC</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="ean">EAN</label>
                    <input type="number" name="ean"  min="0" class="form-control" placeholder="EAN do Produto">
                </div>
                <div class="form-group" style="display: none;">
                    <label for="preco">Preço</label>
                    <input type="number" name="preco"  value="0" min="0" class="form-control" placeholder="Preço">
                </div>
                <div class="form-group" style="display: none;">
                    <label for="quantidade">Quantidade</label>
                    <input type="number" name="quantidade"  value="0" min="0" class="form-control" placeholder="Quantidade">
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição</label>
                    <input type="text" name="descricao"  step="0.01" min="0" class="form-control" placeholder="Descrição do Produto" required>
                </div>
                <div class="form-group">
                    <label for="classe_id">Categorias</label>
                    <select class="form-control" name="classe_id">
                        <option>Selecione a Categoria</option>
                    @foreach($classes as $classe)
                            <option value="{{$classe->id }}">{{$classe->nome}}</option>
                        @endforeach

                    </select>
                </div>
                <button class="btn btn-primary" style="background-color: #0D5C95; color: white;">Adicionar</button>
            </div>
        </div>
    </form>
@endsection