@extends('layout')

@section('cabecalho')
    Produtos
@endsection

@section('conteudo')
    @if(!empty($mensagem))
        <div class="alert alert-success" style="width: 50%">
            {{ $mensagem }}
        </div>
    @endif
        <a href="{{route('form_criar_produto')}}" class="btn mb-2" style="margin-left: 90%; margin-top: -100px; background-color: #0D5C95; color: white;">Adicionar</a>


    <ul class="list-group" style="margin-top: -25px">
        <table class="table table-hover">
            <thead style="background-color: #9d9d9d; color: white;">
            <tr>
                <td>ID</td>
                <td style="width: 40%">Nome</td>
                <td>Unidade</td>
                <td>Descrição</td>
                <td>Tipo</td>
                <td></td>
                <td></td>
                
            </tr>
            </thead>
            <tbody>
        <?php foreach ($produtos as $produto):?>
        <tr>
            <td><?= $produto->id ?></td>
            <td style="width: 40%"><?= $produto->nome ?></td>
            <td><?= $produto->unidade_de_venda ?></td>
            <td><?= $produto->descricao ?></td>
            <td><?= $produto->classe_id ?></td>

            <td><a href="/produtos/{{$produto->id}}" class="btn btn-info btn-sm"><i class="fas fa-edit"></i></a></td>
            <td>
                <form method="post" action="/produtos/remover/{{ $produto->id}}"
                      onsubmit="return confirm('Tem certeza que deseja remover {{ addslashes( $produto->nome )}}?')">
                    @csrf
                    @method('DELETE')
                    <button class="btn btn-danger btn-sm"><i class="far fa-trash-alt"></i></button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
        </table>
        <div style="position: absolute; top: 115%; left: 70%; ">{{ $produtos->links() }}</div>

    </ul>
@endsection